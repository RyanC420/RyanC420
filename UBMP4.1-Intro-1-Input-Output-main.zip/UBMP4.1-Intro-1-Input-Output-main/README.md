# UBMP4.1-Intro-1-Input-Output

## UBMP4.1 Introductory Progamming Activity 1 - Input and Output

Input and output starter program and learning activities for UBMP4.1. For complete
details and descriptions refer to the [UBMP4](https://mirobo.tech/ubmp4) website.  
